The files in this directory are originally from:
https://github.com/microbit-foundation/python-editor-v3/tree/7947f5c9368d9c22ff8fc55088fcf1bbb4cd3eda/public/workers
